##The main project is written in go.
To build. cd into the directory and run `go build`
an exe called image2ftdi.exe should appear. 

##Richards code is in the test folder.
